import { PostGuard } from './blog.guard';

export const guards = [PostGuard];

export * from './blog.guard';
