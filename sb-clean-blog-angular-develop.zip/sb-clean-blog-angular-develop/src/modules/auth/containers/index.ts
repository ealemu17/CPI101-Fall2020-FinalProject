import { LoginComponent } from './login/login.component';

export const containers = [LoginComponent];

export * from './login/login.component';
