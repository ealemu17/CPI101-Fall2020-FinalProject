export interface SBRouteData {
    title?: string;
    activeTopNav?: string;
}
